@extends('layouts.admin') ;

@section('content')


    <h3><i class="fa fa-angle-right"></i> All Products</h3>
          <div class="content-panel">

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

            <div style="padding-top: 20px; padding-right: 5px; padding-left: 5px; " >
            <table class="myTable" class="display dataTable" style="width:100%;" role="grid" aria-describedby="example_info" border="1" >
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Stockable</th>
                    <th>Category</th>
                    <th>Image</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>

        @foreach($product as $products)

              <tr class="
              @if($products->status==1)
                gradeA
              @else
                gradeX
            @endif
              ">
                <td>{{$products->id}}</td>
                <td>{{$products->title}}</td>
                <td class="products_des">
                  {{ Str::limit($products->description, 45) }}
                </td>
                <td>{{$products->price}}</td>
                <td>{{$products->stockable==1?"Yes":"No"}}</td>

                <td>{{$products->ProductCategory->name}}</td>

                <td>
                   <img width="100" src="{{url('images/products/'.$products->image)}}" alt="{{$products->title}}" />
                </td>

                <td class="action_btn" style="width: 135px; padding-left: 3px;">

                   <a href="{{ route('products.show', $products->id)}}" class="btn btn-success"><i class="fa fa-check"></i></a>  

                  <a href="{{ route('products.edit', $products->id)}}" class="btn btn-primary"><i class="fa fa-pencil"></i></a>

                  <form style="float: right;" action="{{ route('products.destroy', $products->id)}}" method="post">
                      @csrf @method('DELETE')
                      <button onclick="return confirm('Are you sure?')"   class="btn btn-danger" type="submit"><i class="fa fa-trash-o "></i></button>
                  </form>

                </td>


              </tr>

        @endforeach


                </tbody>
              </table>
            </div>
          </div>


@endsection