@extends('layouts.admin') ;

@section('content')


<h3><i class="fa fa-angle-right"></i> Product Details</h3>
        
<div class="panel panel-default">
  <div class="panel-heading">
      Category Name: {{$product->name}}
  </div>
  <div class="panel-body">
    

             <ul>
               <li>ID : {{$product->id}}</li>
               <li>Title : {{$product->title}}</li>
               <li>Created Date : {{$product->description}}</li>
               <li>Price : {{$product->price}}</li>
               <li>Stock : {{$product->stockable==1?"yes":"no"}}</li>
               <li>Status : {{$product->status}}</li>
             </ul>
                <img width="200" src="{{url('images/products/'.$product->image)}}" alt="{{$product->title}}" />


  </div>
  <div class="panel-footer">

     <a href="{{ route('products.edit', $product->id)}}" class="btn btn-primary">Edit Category</a>

</div>

@endsection