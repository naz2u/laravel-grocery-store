@extends('layouts.admin') ;

@section('content')


    <h3><i class="fa fa-angle-right"></i> All Products</h3>
          <div class="content-panel">

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

            <div class="adv-table table-responsive">
              <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Products</th>
                    <th>Image</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>

        @foreach($package as $packages)

              <tr class="
              @if($packages->status==1)
                gradeA
              @else
                gradeX
            @endif
              ">
                <td>{{$packages->id}}</td>
                <td>{{$packages->name}}</td>
                <td class="products_des">
                  {{ Str::limit($packages->description, 45) }}
                </td>
                <td>{{$packages->price}}</td>

                 <td>
                  @foreach($packages->products as $products)
                    {{$products->title}} <img width="25" src="{{url('images/products/'.$products->image)}}" /><br/>
                  @endforeach
                </td>
                <td width="90">
                   <img width="90" height="90" src="{{url('images/package/'.$packages->image)}}" alt="{{$packages->name}}" />
                </td>

                <td class="action_btn">

                   <a href="{{ route('package.show', $packages->id)}}" class="btn btn-success"><i class="fa fa-check"></i></a>  

                  <a href="{{ route('package.edit', $packages->id)}}" class="btn btn-primary"><i class="fa fa-pencil"></i></a>

                  <form action="{{ route('package.destroy', $packages->id)}}" method="post">
                      @csrf @method('DELETE')
                      <button onclick="return confirm('Are you sure?')"   class="btn btn-danger" type="submit"><i class="fa fa-trash-o "></i></button>
                  </form>

                </td>


              </tr>

        @endforeach


                </tbody>
              </table>
            </div>
          </div>


@endsection