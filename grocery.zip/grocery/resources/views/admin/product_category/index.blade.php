@extends('layouts.admin');

@section('content')


<div >
  <h3 style="color: #044252" ><i class="fa fa-angle-right" ></i> product-category </h3>
</div>
<div style="padding-top: 30px; padding-right: 15px; " >
<table class="myTable" class="display dataTable" style="width:100%;" role="grid" aria-describedby="example_info" border="1" >
					<thead class="New">
							<tr>
								<th>#</th>
								<th>Name</th>
								<th>ACTION</th>
								
							</tr>
					</thead>
					<tbody class="letter" style="color: #222324" >
					
		                  @foreach($category as $cat)

                  <tr class="@if($cat->status==1)
                  		text-primary
                  	@else
                  		text-danger
                  	@endif">

                    <td>{{$cat->id}}</td>
                    <td>{{$cat->name}}</td>
                    <td class="action_btn">
                       
                      <a href="{{ route('product-category.show', $cat->id)}}"> <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button></a>
                     <a href="{{ route('product-category.edit', $cat->id)}}"> <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a>

                     <form action="{{ route('product-category.destroy', $cat->id)}}"  method="post">
                            @csrf @method('DELETE')

                     	<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i>
                     	</button>

                      </form>

                    </td>
                  </tr>

                @endforeach

						
					</tbody>
					
				</table>
			</div>
	

@endsection

